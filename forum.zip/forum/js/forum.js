var cardColor="success";
var cardAll="<div><cardBody></cardBody><addCard></addCard></div>"

Vue.component('inputText',{
    template:""
})

Vue.component('cardBody', {
    methods:{
        love(index){
            this.$emit('showLove',index);
        }
    },
    props:['cards','class_one','class_two','class_three'],
    template: '<div><div v-for="(c,index) in cards" style="height=50px"><div :class="class_one" style="max-width: 18rem;"><div class="card-header">{{c.writer}}<i class="far fa-heart" :style="c.love" @click="love(index)"></i></div><div :class="class_two"><a :class="class_three" href=""><h5 class="card-title">{{c.title}}</h5></a><p class="card-text">{{c.summary}}</p></div></div></div></div>'
});

Vue.component('addCard',{
    methods:{
        addC(){
            this.$emit('add_button');
        }
    },
    template:'<a style="width:100%; position:fixed; left:85%; bottom:12%;" @click="addC"><i class="fas fa-plus-circle" style="font-size:30px;"></i></a>'
})

Vue.component('addText',{
    data:function(){
        return{
            card:{
                title:"",
                summary:""
            },
            title:"",
            summary:""
        }
    },
    methods:{
        addData(){
            if(this.title&&this.summary){
                this.card.title=this.title;
                this.card.summary=this.summary;
                this.$emit('addCard',this.title,this.summary);
                this.title="";
                this.summary="";
            }
        }
    },
    template:'<div class="mt-5"><div><label class="mr-3">标题</label><input v-model="title" type="text" style="width:80%"></div><p><div class="summary"><label class="mr-3">内容</label><input v-model="summary" type="text" style="width:80%;height:150px"></div><button class="btn btn-secondary mt-3" type="button" style="float:right;margin-right:10px" @click="addData">提交</button></div>'
})

Vue.component('bottom',{
    methods:{
        showUser(){
            this.$emit('show_user')
        },
        showTalk(){
            this.$emit('show_talk')
        }
    },
    template:'<div><nav class="navbar fixed-bottom navbar-light bg-light" style="height:60px"><div class="row mt-3"><div class="col"><i class="fa fa-calendar"></i><p><a @click="showTalk">论坛</a></p></div><div class="col"><i class="fa fa-user"></i><p><a @click="showUser" style="color:black">用户</a></p></div></div></nav></div>'
})

Vue.component('card',{
    data:function(){
        return{
            flag:true,
            index:-1
        }
    },
    methods:{
        add_card(){
            this.flag=false;
        },
        add_data(title,summary){
            this.flag=true;
            this.$emit('addCard',title,summary);
        },
        show_love(index){
            this.$emit('showLove',index);
        }
    },
    props:['cards','class_one','class_two','class_three'],
    template:"<div class='card-colums ml-3' style='max-height:550px;overflow-y:auto;min-height:250px;'><cardBody @showLove='show_love' v-show='flag' :cards='cards' :class_one='class_one' :class_two='class_two' :class_three='class_three'></cardBody><addCard @add_button='add_card'></addCard><addText v-show='!flag' @addCard='add_data'></addText></div>"
})

Vue.component('te',{
    methods:{
        showTe(){
            this.$emit('show_te');
        }
    },
    template:'<div class="ml-4 mt-3"><i class="fas fa-file-alt" style="font-size:20px;"></i><span class="ml-3">我的帖子</span><i class="fas fa-chevron-right" style="font-size:15px;float:right;margin-right:15px" @click="showTe"></i></div>'
})

Vue.component('theme',{
    data:function(){
        return {
            color:1,
        }
    },
    methods:{
        getColor(value){
            this.color=value.target.value;
            this.$emit('get_color',this.color)
        }
    },
    template:'<div class="mt-3" style="margin-left:11px;margin-bottom:0px"><div class="input-group mb-3"><div class="input-group-prepend"><label class="border-0 input-group-text justify-content-right bg-white" style="width: 220px"><i style="font-size:20px;" class="fas fa-palette"></i><span style="margin-left:14px">主题</span><br></label></div><select class="custom-select text-black border-0" @change="getColor"><option selected value="0">绿色</option><option value="1">蓝色</option><option value="2">红色</option><option value="3">黄色</option></select></div></div>'
})

Vue.component('name',{
    template:'<div class="head" style="width: 100%"><div class="media"><i class="far fa-user-circle fa-3x ml-3 mr-3 mt-2"></i><div class="media-body"><h5 class="mt-0 mb-0">ye</h5><small><p class="m-0 p-0">LV 999999999+</p><p class="m-0">SVIP 100</p></small></div><i class="fas fa-chevron-right fa-1x ml-3 mr-3 mt-4"></i></div></div>'
})

Vue.component('subject',{
    template:'<div class="ml-4"><i class="fas fa-book" style="font-size:20px;"></i><span class="ml-3">我的课程</span><i class="fas fa-chevron-right" style="font-size:15px;float:right;margin-right:15px"></i></div>'
})

Vue.component('collect',{
    methods:{
        showLove(){
            this.$emit('show_love');
        }
    },
    template:'<div class="ml-4 mt-4"><i class="fas fa-copy" style="font-size:20px;"></i><span class="ml-3">我的收藏</span><i class="fas fa-chevron-right" style="font-size:15px;float:right;margin-right:15px" @click="showLove"></i></div>'
})

Vue.component('history',{
    template:'<div class="ml-4 mt-4"><i class="fas fa-clock" style="font-size:20px;"></i><span class="ml-3">浏览历史</span><i class="fas fa-chevron-right" style="font-size:15px;float:right;margin-right:15px"></i></div>'
})

Vue.component('user',{
    methods:{
        getColor(color){
            this.$emit('getC',color);
        },
        showTe(){
            this.$emit('show_te');
        },
        showLove(){
            this.$emit('show_love');
            console.log('click');
        }
    },
    template:"<div class='word-sentence' style='margin-top: 55px;'><name></name><div class='mt-5'><te @show_te='showTe'></te><theme @get_color='getColor'></theme><subject></subject><collect @show_love='showLove'></collect><history></history></div></div>"
})

Vue.component('showte',{
    props:['cardShow','class_one','class_two','class_three'],
    methods:{
        remove(c){
            this.$emit('removeTe',c.title)
        }
    },
    template:'<div class="card-colums ml-3"><div v-for="c in cardShow" style="height=50px"><div :class="class_one" style="max-width: 18rem;"><div class="card-header">{{c.writer}}<i class="fas fa-times" style="float:right;margin-top:4px" @click="remove(c)"></i></div><div :class="class_two"><a :class="class_three" href=""><h5 class="card-title">{{c.title}}</h5></a><p class="card-text">{{c.summary}}</p></div></div></div></div>'
})

Vue.component('showLove',{
    props:['loveShow','class_one','class_two','class_three'],
    template:'<div class="card-colums ml-3"><div v-for="c in loveShow" style="height=50px"><div :class="class_one" style="max-width: 18rem;"><div class="card-header">{{c.writer}}<i class="fas fa-times" style="float:right;margin-top:4px""></i></div><div :class="class_two"><a :class="class_three" href=""><h5 class="card-title">{{c.title}}</h5></a><p class="card-text">{{c.summary}}</p></div></div></div></div>'
})

new Vue({
    el:'#card',
    data:function(){
        return {
            flag:true,
            flag_te:true,
            flag_love:true,
            colors:["success","primary","danger","warning"],
            cards:[
                    {
                        title:"【倒计时60天】考研人，你是考什么坚持下来的",
                        writer:"无岚x",
                        summary:"#2019年考研",
                        love:"float:right;margin-top:3px;"
                    },{
                        title:"【考研干货】19考研政治各专题重大汇总（更新中）",
                        writer:"你丑你别说",
                        summary:"#2019年考研",
                        love:"float:right;margin-top:3px;"
                    },{
                        title:"【在线答疑】手把手教你考研报名",
                        writer:"Peter",
                        summary:"#2019年考研",
                        love:"float:right;margin-top:3px;"
                    },{
                        title:"【小确幸】记录每日小确幸，原来你就是考验锦鲤",
                        writer:"ye",
                        summary:"#2019年考研",
                        love:"float:right;margin-top:3px;"
                    }
                ],
            cardShow:[],
            loveShow:[],
            color:"",
            class_one:"card border-success mb-3 mt-3",
            class_two:"card-body text-success",
            class_three:"text-success",
            index:-1
        }
    },
    methods:{
        showUser(){
            this.flag=false;
            this.flag_te=true;
            this.flag_love=true;
        },
        getColor(color){
            this.color=this.colors[color];
            this.class_one="card border-"+this.color+" mb-3 mt-3";
            this.class_two="card-body text-"+this.color;
            this.class_three="text-"+this.color;
        },
        showTalk(){
            this.flag=true;
            this.flag_te=true;
            this.flag_love=true;
        },
        showTe(){
            this.cardShow=[];
            this.flag_te=false;
            this.cards.forEach(function(item){
                if(item.writer=="ye"){
                    this.cardShow.push(item);
                }
            }.bind(this));
        },
        addData(title,summary){
            var b={};
            b.title=title;
            b.summary=summary;
            b.writer="ye"
            b.love="float:right;margin-top:3px;"
            this.cards.push(b);
        },
        remove_te(title){
            var b=[];
            console.log(title);
            this.cards.forEach(function(item){
                if(item.title!=title){
                    b.push(item);
                };
            }.bind(this));
            this.cards=b;
            b=[];
            this.cardShow.forEach(function(item){
                if(item.title!=title){
                    b.push(item);
                };
            }.bind(this));
            this.cardShow=b;
        },
        show_love(index){
            console.log(index);
            if(this.cards[index].love=="float:right;margin-top:3px;"){
                this.cards[index].love="float:right;margin-top:3px;color:red";
            } else{
                this.cards[index].love="float:right;margin-top:3px;"
            }
        },
        showL(){
            this.loveShow=[];            
            this.flag_love=false;
            this.cards.forEach(function(item){
                if(item.love=="float:right;margin-top:3px;color:red"){
                    this.loveShow.push(item);
                }
            }.bind(this));
        }
    },
    template:"<div><card @showLove='show_love' v-show='flag' :cards='cards' :class_one='class_one' :class_two='class_two' :class_three='class_three' @addCard='addData'></card><user @show_love='showL' @show_te='showTe' v-show='!flag&&flag_te&flag_love' @getC='getColor'></user><showte @removeTe='remove_te' v-show='!flag_te' :cardShow='cardShow' :class_one='class_one' :class_two='class_two' :class_three='class_three'></showte><showLove v-show='!flag_love' :loveShow='loveShow' :class_one='class_one' :class_two='class_two' :class_three='class_three'></showLove><bottom @show_user='showUser' @show_talk='showTalk'></bottom></div>"
})