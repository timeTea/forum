var number=document.getElementById("number");
var password=document.getElementById("password");

var login = document.getElementById("login");
login.addEventListener("click",function(){
    console.log("click");
    console.log(number.value);
    console.log(password.value);
    if(number.value=="ye"&&password.value=="123"){
        window.location.href='forum.html';
    }
})